/* validate() checks that every field marked with * has been filled in.
   It returns false (which cancels the submit) if anything is missing. */
function validate() {
	var name      = document.getElementById("name").value;
	var email     = document.getElementById("Eaddress").value;
	var phone     = document.getElementById("PhoneNumber").value;
	var movie     = document.getElementById("ChosenMovie").value;
	var time      = document.getElementById("ScreeningTime").value;
	var ticket    = document.querySelector("input[name='TicketType']:checked");
	var tickets   = document.getElementById("tickets").value;
	var billing   = document.getElementById("BillingAddress").value;
	var payment   = document.querySelector("input[name='PaymentType']:checked");
	var cardNum   = document.getElementById("CardNumber").value;
	var expiry    = document.getElementById("ExpiryDate").value;
	var ccv       = document.getElementById("CCV").value;

	var errMsg = [];			/* list of error messages */
	var result = true;

	/* Check that all required (*) data has been entered */
	if (name.trim() == "")    { errMsg.push("Full name cannot be empty."); }
	if (email.trim() == "")   { errMsg.push("Email address cannot be empty."); }
	if (phone.trim() == "")   { errMsg.push("Phone number cannot be empty."); }
	if (movie == "")          { errMsg.push("A movie must be selected."); }
	if (time == "")           { errMsg.push("A screening time must be selected."); }
	if (ticket == null)       { errMsg.push("A ticket type must be selected."); }
	if (tickets.trim() == "") { errMsg.push("Number of tickets cannot be empty."); }
	if (billing.trim() == "") { errMsg.push("Billing email address cannot be empty."); }
	if (payment == null)      { errMsg.push("A payment type must be selected."); }
	if (cardNum.trim() == "") { errMsg.push("Card number cannot be empty."); }
	if (expiry.trim() == "")  { errMsg.push("Expiry date cannot be empty."); }
	if (ccv.trim() == "")     { errMsg.push("CCV cannot be empty."); }

	/* Display the error window if any errors were found */
	if (errMsg.length > 0) {
		showErrors(errMsg);
		result = false;			/* if its false, it cancels the form submission */
	}
	return result;
}

/* showErrors() builds a dark overlay and a centred popup window.
   All styling is applied here, so no extra CSS file is needed. */
function showErrors(errMsg) {
	/* remove any existing error window first so they don't stack up */
	closeErrors();

	/* overlay that covers the whole screen and blocks clicks on the page */
	var overlay = document.createElement("div");
	overlay.id = "scrnOverlay";

	/* popup window centred on screen */
	var win = document.createElement("section");
	win.id = "errWin";
	win.style.position = "fixed";

	var list = document.createElement("ul");
	for (var i = 0; i < errMsg.length; i++) {
		var item = document.createElement("li");
		item.textContent = errMsg[i];
		list.appendChild(item);
	}

	var closeBtn = document.createElement("a");
	closeBtn.href = "#";
	closeBtn.id = "errBtn";
	closeBtn.textContent = "Close";
	closeBtn.addEventListener("click", function (e) {
		e.preventDefault();
		closeErrors();
	});

	win.appendChild(list);
	win.appendChild(closeBtn);
	document.body.appendChild(overlay);
	document.body.appendChild(win);
}

/* closeErrors() removes the overlay and error window */
function closeErrors() {
	var overlay = document.getElementById("scrnOverlay");
	var win = document.getElementById("errWin");
	if (overlay) { overlay.remove(); }
	if (win) { win.remove(); }
}

/* link validate() to the form's submit event */
function init() {
	document.getElementById("bookingform").addEventListener("submit", function (e) {
		if (!validate()) {
			e.preventDefault();		/* stop the form being sent */
		}
	});
}

/* run init() once the page has loaded */
window.addEventListener("load", init);

function validate() {
	var sid = document.getElementById("sid").value;
	var pwd1 = document.getElementById("pwd1").value;
	var pwd2 = document.getElementById("pwd2").value;
	var uname = document.getElementById("uname").value;
	var email = document.getElementById("Eaddress").value;
	var phone = document.getElementById("PhoneNumber").value;
	var genm = document.getElementById("genm").checked;
	var genf = document.getElementById("genf").checked;
	var country = document.getElementById("Country").value;
	var genre = document.querySelectorAll("input[name='Genre']:checked");

	var errMsg = [];
	var result = true;


	if (sid.trim() == "") { errMsg.push("Username cannot be empty."); }
	if (pwd1 == "") { errMsg.push("Password cannot be empty."); }
	if (pwd2 == "") { errMsg.push("Retype password cannot be empty."); }
	if (uname.trim() == "") { errMsg.push("Name cannot be empty."); }
	if (email.trim() == "") { errMsg.push("Email address cannot be empty."); }
	if (phone.trim() == "") { errMsg.push("Phone number cannot be empty."); }
	if (!genm && !genf) { errMsg.push("A gender must be selected."); }
	if (country == "Choose"){ errMsg.push("A country must be selected."); }
	if (genre.length == 0) { errMsg.push("At least one preferred movie genre must be selected."); }

	
	if (pwd1 != pwd2) {
		errMsg.push("Passwords do not match.");
	}


	var minPwdLength = 10;
	if (pwd1 != "" && pwd1.length < minPwdLength) {
		errMsg.push("Password must be at least " + minPwdLength + " characters long.");
	}


	var phonePattern = /^[0-9]{8,15}$/;
	if (phone.trim() != "" && !phonePattern.test(phone.trim())) {
		errMsg.push("Phone number must be 8 to 15 digits (numbers only).");
	}

	if (errMsg.length > 0) {
		showErrors(errMsg);
		result = false;			
	}
	return result;
}


function showErrors(errMsg) {

	closeErrors();

	var overlay = document.createElement("div");
	overlay.id = "scrnOverlay";

	var win = document.createElement("section");
	win.id = "errWin";

	var list = document.createElement("ul");
	for (var i = 0; i < errMsg.length; i++) {
		var item = document.createElement("li");
		item.textContent = errMsg[i];
		list.appendChild(item);
	}

	var closeBtn = document.createElement("a");
	closeBtn.href = "#";
	closeBtn.id = "errBtn";
	closeBtn.textContent = "Close";
	closeBtn.addEventListener("click", function (e) {
		e.preventDefault();
		closeErrors();
	});

	win.appendChild(list);
	win.appendChild(closeBtn);
	document.body.appendChild(overlay);
	document.body.appendChild(win);
}

function closeErrors() {
	var overlay = document.getElementById("scrnOverlay");
	var win = document.getElementById("errWin");
	if (overlay) { overlay.remove(); }
	if (win) { win.remove(); }
}

function init() {
	document.getElementById("regform").addEventListener("submit", function (e) {
		if (!validate()) {
			e.preventDefault();		
		}
	});
}


window.addEventListener("load", init);
/* ===== Zohan ===== */
 
/* function showZohanWin will show the Zohan window */
function showZohanWin () {
	var zohanWin = document.getElementById("zohanWin");        /* get element "zohanWin" */
	var scrnOverlay = document.getElementById("scrnOverlay");  /* get element "scrnOverlay" */
 
	zohanWin.style.display = "block";          /* display element zohanWin */
	scrnOverlay.style.visibility = "visible";  /* display element scrnOverlay */
}
 
/* function hideZohanWin will hide the Zohan window */
function hideZohanWin () {
	var zohanWin = document.getElementById("zohanWin");        /* get element "zohanWin" */
	var scrnOverlay = document.getElementById("scrnOverlay");  /* get element "scrnOverlay" */
 
	scrnOverlay.style.visibility = "hidden";   /* hide element scrnOverlay */
	zohanWin.style.display = "none";           /* hide element zohanWin */

												/*same logic applies to all other instances*/
}
 
/* ===== 50 First Dates ===== */
 
/* function showFfdWin will show the 50 First Dates window */
function showFfdWin () {
	var ffdWin = document.getElementById("ffdWin");       
	var scrnOverlay = document.getElementById("scrnOverlay");  
 
	ffdWin.style.display = "block";          
	scrnOverlay.style.visibility = "visible";  
}
 
/* function hideFfdWin will hide the 50 First Dates window */
function hideFfdWin () {
	var ffdWin = document.getElementById("ffdWin");        
	var scrnOverlay = document.getElementById("scrnOverlay");  
 
	scrnOverlay.style.visibility = "hidden";   
	ffdWin.style.display = "none";           
}
 
/* ===== Now You See Me ===== */
 
/* function showNysmWin will show the Now You See Me window */
function showNysmWin () {
	var nysmWin = document.getElementById("nysmWin");       
	var scrnOverlay = document.getElementById("scrnOverlay");  
 
	nysmWin.style.display = "block";          
	scrnOverlay.style.visibility = "visible";  
}
 
/* function hideNysmWin will hide the Now You See Me window */
function hideNysmWin () {
	var nysmWin = document.getElementById("nysmWin");     
	var scrnOverlay = document.getElementById("scrnOverlay"); 
 
	scrnOverlay.style.visibility = "hidden";  
	nysmWin.style.display = "none";          
}
 
/* ===== Now You See Me 2 ===== */
 
/* function showNysm2Win will show the Now You See Me 2 window */
function showNysm2Win () {
	var nysm2Win = document.getElementById("nysm2Win");    
	var scrnOverlay = document.getElementById("scrnOverlay");
 
	nysm2Win.style.display = "block";          
	scrnOverlay.style.visibility = "visible";  
}
 
/* function hideNysm2Win will hide the Now You See Me 2 window */
function hideNysm2Win () {
	var nysm2Win = document.getElementById("nysm2Win");       
	var scrnOverlay = document.getElementById("scrnOverlay");  
 
	scrnOverlay.style.visibility = "hidden";   
	nysm2Win.style.display = "none";         
}
 
/* ===== Fight Club ===== */
 
/* function showFcWin will show the Fight Club window */
function showFcWin () {
	var fcWin = document.getElementById("fcWin");     
	var scrnOverlay = document.getElementById("scrnOverlay");  
 
	fcWin.style.display = "block";         
	scrnOverlay.style.visibility = "visible";
}
 
/* function hideFcWin will hide the Fight Club window */
function hideFcWin () {
	var fcWin = document.getElementById("fcWin");        
	var scrnOverlay = document.getElementById("scrnOverlay");  
 
	scrnOverlay.style.visibility = "hidden";  
	fcWin.style.display = "none";      
}
 
/* ===== Avatar ===== */
 
/* function showAvatarWin will show the Avatar1 window */
function showAvatarWin () {
	var avatarWin = document.getElementById("avatarWin");       
	var scrnOverlay = document.getElementById("scrnOverlay"); 
 
	avatarWin.style.display = "block";         
	scrnOverlay.style.visibility = "visible"; 
}
 
/* function hideAvatarWin will hide the Avatar1 window */
function hideAvatarWin () {
	var avatarWin = document.getElementById("avatarWin");       
	var scrnOverlay = document.getElementById("scrnOverlay");  
 
	scrnOverlay.style.visibility = "hidden";   
	avatarWin.style.display = "none";          
}
 
/* ===== Avatar2 ===== */
 
/* function showAvatar2Win will show the Avatar2 */
function showAvatar2Win () {
	var avatar2Win = document.getElementById("avatar2Win");        
	var scrnOverlay = document.getElementById("scrnOverlay");  
 
	avatar2Win.style.display = "block";        
	scrnOverlay.style.visibility = "visible";  
}
 
/* function hideAvatar2Win will hide the Avatar2 */
function hideAvatar2Win () {
	var avatar2Win = document.getElementById("avatar2Win");       
	var scrnOverlay = document.getElementById("scrnOverlay");  
 
	scrnOverlay.style.visibility = "hidden";  
	avatar2Win.style.display = "none";  
}
 
/* ===== Avatar3 ===== */
 
/* function showAvatar3Win will show the Avatar3 */
function showAvatar3Win () {
	var avatar3Win = document.getElementById("avatar3Win");        
	var scrnOverlay = document.getElementById("scrnOverlay");  
 
	avatar3Win.style.display = "block";       
	scrnOverlay.style.visibility = "visible";  
}
 
/* function hideAvatar3Win will hide the Avatar3 */
function hideAvatar3Win () {
	var avatar3Win = document.getElementById("avatar3Win");        
	var scrnOverlay = document.getElementById("scrnOverlay");  
 
	scrnOverlay.style.visibility = "hidden"; 
	avatar3Win.style.display = "none";           
}
 
/* link functions to appropriate events of corresponding HTML elements */
function init () {
	/* link the variables to the HTML elements */
	var zohanBtn = document.getElementById("zohanBtn");      /* get element "zohanBtn" */
	var zohanClose = document.getElementById("zohanClose");  /* get element "zohanClose" */ /*rinse and repeat*/
	var ffdBtn = document.getElementById("ffdBtn");      
	var ffdClose = document.getElementById("ffdClose");  
	var nysmBtn = document.getElementById("nysmBtn");      
	var nysmClose = document.getElementById("nysmClose");  
	var nysm2Btn = document.getElementById("nysm2Btn");      
	var nysm2Close = document.getElementById("nysm2Close");  
	var fcBtn = document.getElementById("fcBtn");     
	var fcClose = document.getElementById("fcClose");  
	var avatarBtn = document.getElementById("avatarBtn");      
	var avatarClose = document.getElementById("avatarClose");  
	var avatar2Btn = document.getElementById("avatar2Btn");      
	var avatar2Close = document.getElementById("avatar2Close");  
	var avatar3Btn = document.getElementById("avatar3Btn");      
	var avatar3Close = document.getElementById("avatar3Close");  
 
	zohanBtn.onclick = showZohanWin;     /* poster click opens the window */
	zohanClose.onclick = hideZohanWin;   /* Close click hides the window */ /*rinse and repeat*/
 
	ffdBtn.onclick = showFfdWin;     
	ffdClose.onclick = hideFfdWin;   
 
	nysmBtn.onclick = showNysmWin;     
	nysmClose.onclick = hideNysmWin;   
 
	nysm2Btn.onclick = showNysm2Win;    
	nysm2Close.onclick = hideNysm2Win;  

	fcBtn.onclick = showFcWin;    
	fcClose.onclick = hideFcWin;   

	avatarBtn.onclick = showAvatarWin;    
	avatarClose.onclick = hideAvatarWin;   
 
	avatar2Btn.onclick = showAvatar2Win;    
	avatar2Close.onclick = hideAvatar2Win;   
 
	avatar3Btn.onclick = showAvatar3Win;     
	avatar3Close.onclick = hideAvatar3Win;   
}

window.onload = init;


/* 		&& and
	/* checks if both are true */
	/* || or */
	/*checks if either condition meets the requirement */
	/* !  not */
	/* checks if x does not equal to y */
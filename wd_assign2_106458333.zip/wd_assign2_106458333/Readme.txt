WEBSITE STRUCTURE:
The structure of the website begins at the home page. Each of the branching pages are all interconnected with navigation links,
meaning that any part of the whole assignment is accessible from any page. (e.g the 'movie booking' page can be accessed from the 'home' page, but also from the 'current screening' page.)

JAVASCRIPT LOGIC:
The logic behind the JavaScript validation essentially follows the same structure from the previous "regform" validations that were conducted in the lab exercises, just on a slightly larger scale.
Each movie that is displayed in the assignment contains an id that is connected to a variable in the JavaScript. When the page is loaded, the program is executed and waits for the user to click on one of the boxes.
When a box/movie is clicked, the program shows/opens a small window which has the corresponding id to the movie. Then that small window contains all the information that is releated to the movie.

KNOWN ISSUES AND LIMITATIONS:
During the coding of this assignment, I (yotam) did not find a way to carry over information from the 'movies.html' to the 'booking.html'. Meaning that When a user attempts to book a movie screening time, they must
re-select the desired movie, as well as a correct screening time. To combat this, an extra line of text has been included to the booking page to remind customers to re-select the necessary fields.
Whilst this does not solve the core issue, it can (hopefully) prevent users from booking the wrong movie/screening.




GitHub Link:


Mercury Link:


References:

- Sony Pictures Entertainment (n.d.) Watch the "You Don't Mess With the Zohan" trailer [YouTube video]. Available at: https://www.youtube.com/watch?v=ucmnTmYpGhI (Accessed: 25 October 2026).

- Sony Pics at Home (n.d.) Official Trailer: 50 First Dates (2004) [YouTube video]. Available at: https://www.youtube.com/watch?v=17KJk3ErIx0 (Accessed: 25 October 2026).

- Rotten Tomatoes Trailers (n.d.) Now You See Me Official Trailer #2 (2013) - Mark Ruffalo, Morgan Freeman Movie HD [YouTube video]. Available at: https://www.youtube.com/watch?v=KzJNYYkkhzc (Accessed: 25 October 2026).

- Rotten Tomatoes Trailers (n.d.) Now You See Me 2 Official Trailer #1 (2016) - Mark Ruffalo, Lizzy Caplan Movie HD [YouTube video]. Available at: https://www.youtube.com/watch?v=4I8rVcSQbic (Accessed: 25 October 2026).

- Rotten Tomatoes Classic Trailers (n.d.) Fight Club (1999) Trailer #1 | Movieclips Classic Trailers [YouTube video]. Available at: https://www.youtube.com/watch?v=qtRKdVHc-cE (Accessed: 25 October 2026).

- 20th Century Studios (n.d.) Avatar | Official Trailer (HD) | 20th Century FOX [YouTube video]. Available at: https://www.youtube.com/watch?v=5PSNL1qE6VY (Accessed: 25 October 2026).

- Avatar (n.d.) Avatar: The Way of Water | Official Trailer [YouTube video]. Available at: https://www.youtube.com/watch?v=d9MyW72ELq0 (Accessed: 25 October 2026).

- Avatar (n.d.) Avatar: Fire and Ash | Official Trailer [YouTube video]. Available at: https://www.youtube.com/watch?v=nb_fFj_0rq8 (Accessed: 25 October 2026).

- Mooneeram, F. (2017) Red cinema chair [Photograph]. Available at: https://unsplash.com/photos/red-cinema-chair-evlkOfkQ5rE (Accessed: 25 October 2026).

- W3Schools (n.d.) HTML Tutorial. Available at: https://www.w3schools.com/html/ (Accessed: 25 October 2026).